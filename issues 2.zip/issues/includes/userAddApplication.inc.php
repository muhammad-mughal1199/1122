<?php
session_start();

if (isset($_POST["submit"])) {
    // Include database connection and functions
    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';

    // Get form data
    $title = $_POST["title"];
    $description = $_POST["description"];
    $status = false; // Default status is Pending

    // Check for empty input fields
    if (empty($title) || empty($description)) {
        header("location: ../pages/application/addApplication.php?error=emptyInput");
        exit();
    }

    // Insert application into the database
    addApplication($conn, $title, $description, $status);

} else {
    header("location: ../pages/application/addApplication.php");
    exit();
}

// Function to add an application to the database
function addApplication($conn, $title, $description, $status) {
    $sql = "INSERT INTO applications (title, description, status, userId) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../pages/application/addApplication.php?error=stmtFailed");
        exit();
    }

    $userId = $_SESSION["userId"]; // Assuming userId is stored in session

    mysqli_stmt_bind_param($stmt, "ssii", $title, $description, $status, $userId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("location: ../pages/application/addApplication.php?error=none");
    exit();
}
